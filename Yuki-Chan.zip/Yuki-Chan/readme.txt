This is my first ever Utau! 
I made her to make covers and original songs for me and anyone who cares!

Name: �[������� (Yuki-chan)
type: CV Japanese
Finished: TBA
Updated: TBA
Download page: TBA
Wiki page: TBA


Lore: 
Yuki is a very bubbly, cute girl. But, she is also very polite and respecting. 
She got a major injury on her ankle when she was a child, so she wears a bandaid over it.
She has a long pony tail with a holly berry in her hair. She also wears a mini skirt and sweater! Her name means "Evening Holly".
Yuki has a younger brother named �ŏ�-kun (Mogami-kun) who she cherishes very much. �ŏ�-kun is a separate Utau, you can find his download page on Yuki-chan's Wiki.


Details: 
She is a teenager, age 15
All her her text files are SHIFT-JIS
Her full name is ���[�� [Nagare Yuki], roughly meaning "Flowing Evening Hollys"

Details about me:
I use OpenUtau, and I used to use Utalet.
I'm on a MiniMac
YT: https://www.youtube.com/@OREO_13-13
Insta: https://www.instagram.com/ore.o1313/?hl=en
Discord Username: _yara_loves_oreos_


to give credits, put her download link in the description of your song/audio. You don't have to, but I'd be deilighted!

Voiced and produced by Oreo [me] ? 2026 All Rights Reserved.