This is my second ever Utau! 
I made him to make covers and original songs for me and anyone who cares!
Also bc in the lore Yuki-chan has a brother

Name: �ŏキ�� (mogami-kun)
type: CV Japanese
Finished: Oct. 5. 2026
Updated: Oct. 5. 2026
Download page: https://oreosatsea-boop.github.io/My-Utau-Downloads/
Wiki page: TBA


Lore: 
Mogami is an outgoing, bright boy. Sometimes he can be mischiveous and get in trouble. 
He loves skateboarding and is very arrogant about it, saying he is the best out of his class.
His design consists of a sweater, blueberry themed skateboard and headphones, and red shorts. His name litterally means "The best".
Yuki and Mogami are sibilings, they both have the same download page!


Details: 
He is a minor, age 9
All of his text files are SHIFT-JIS
His full name is ���ŏ� [Nagare Mogami], roughly meaning "The best flow" (it kinda sounds stupid, but its bc �� is their last name so)

Details about me:
I use OpenUtau, and I used to use Utalet.
I'm on a MiniMac
YT: https://www.youtube.com/@OREO_13-13
Insta: https://www.instagram.com/ore.o1313/?hl=en
Discord Username: _yara_loves_oreos_

Details about voice provider:
Youtube: https://www.youtube.com/@Teto-x8g
TikTok: https://www.tiktok.com/@teto_tiktok38
Twitch: https://www.twitch.tv/twichteto38
Shout out to him!!!



to give credits, put his download link in the description of your song/audio. You don't have to, but I'd be deilighted!

Voiced by Alien produced by Oreo [me] ? 2026 All Rights Reserved.